package com.example.RP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RpApplicationTests {

	@Test
	void contextLoads() {
	}

}
